<?php
/* Test Test cases generated on: 2011-12-30 15:35:58 : 1325239558*/
App::uses('Test', 'Model');

/**
 * Test Test Case
 *
 */
class TestTestCase extends CakeTestCase {
/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array('app.test', 'app.candidate', 'app.test_question');

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();

		$this->Test = ClassRegistry::init('Test');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Test);

		parent::tearDown();
	}

}
