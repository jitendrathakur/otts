<?php
class AppModel extends Model
{
    /**
     * This variable is used to attach behaviours to model.
     *
     * @var array
     */
    public $actsAs = array('Containable');


}//end class