<?php
class Result extends AppModel {



	public $belongsTo = array('User', 'Test');

	//public $hasMany = array('Subject');

}//end Course()
