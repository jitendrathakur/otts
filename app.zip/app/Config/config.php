<?php

$config = array();

$config['adminGroupId'] = 1;

$config['studentGroupId'] = 3;

$config['employeeGroupId'] = 5;

?>